Drop-in prompt data for Anime_Creature_Lite_v4.
Install ComfyUI-EZ-AF-Nodes separately, then merge this folder into its installed custom node folder.
See the root README and docs/PLACEHOLDER_MAP.csv for the exact chain order.
