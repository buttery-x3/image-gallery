# Anime Creature Lite v4 metadata nodes

Adds a metadata builder and PNG saver used by the included workflow. The saver can also write a sidecar JSON file.
