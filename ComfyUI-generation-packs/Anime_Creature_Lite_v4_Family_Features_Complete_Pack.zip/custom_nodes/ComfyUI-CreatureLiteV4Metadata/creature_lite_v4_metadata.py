import json
import os
import re
from typing import Any

import numpy as np
from PIL import Image
from PIL.PngImagePlugin import PngInfo

try:
    import folder_paths
except Exception:
    folder_paths = None

try:
    from comfy.cli_args import args
except Exception:
    class _Args:
        disable_metadata = False
    args = _Args()

SPECIES_TO_FAMILY = {'cat': 'FELINE', 'lion': 'FELINE', 'tiger': 'FELINE', 'panther': 'FELINE', 'fox': 'CANINE', 'wolf': 'CANINE', 'dog': 'CANINE', 'hyena': 'CANINE', 'kitsune': 'CANINE', 'bunny': 'RABBIT', 'raccoon': 'RACCOON', 'deer': 'DEER', 'stag': 'DEER', 'cow': 'HORNEDHOOF', 'sheep': 'HORNEDHOOF', 'goat': 'HORNEDHOOF', 'ram': 'HORNEDHOOF', 'bull': 'HORNEDHOOF', 'pony': 'EQUINE', 'horse': 'EQUINE', 'bear': 'HEAVYMAMMAL', 'boar': 'HEAVYMAMMAL', 'bat': 'BAT', 'dragon': 'DRAGON', 'oni-dragon': 'DRAGON', 'lizard': 'REPTILE', 'alligator': 'REPTILE', 'crocodile': 'REPTILE', 'gecko': 'REPTILE', 'chameleon': 'REPTILE', 'lamia': 'SERPENT', 'frog': 'SMOOTH', 'axolotl': 'SMOOTH', 'slime': 'SMOOTH', 'bird': 'AVIAN', 'raven': 'AVIAN', 'owl': 'AVIAN', 'eagle': 'AVIAN', 'vulture': 'AVIAN', 'harpy': 'AVIAN', 'shark': 'AQUATIC', 'koi': 'AQUATIC', 'mermaid': 'AQUATIC', 'kraken': 'CEPHALOPOD', 'bee': 'WINGEDINSECT', 'moth': 'WINGEDINSECT', 'dragonfly': 'WINGEDINSECT', 'beetle': 'ARMOREDINSECT', 'mantis': 'ARMOREDINSECT', 'spider': 'ARACHNID', 'scorpion': 'ARACHNID', 'centipede': 'ARACHNID', 'demon': 'DEMON', 'oni': 'DEMON', 'succubus': 'DEMON', 'ghost': 'SPECTRAL', 'vampire': 'SPECTRAL', 'angel': 'ANGEL'}


def _text(v: Any) -> str:
    if v is None:
        return ''
    return str(v).strip()


def _gender(core: str) -> str:
    low = core.lower()
    if '1woman' in low or 'adult woman' in low:
        return 'woman'
    if '1man' in low or 'adult man' in low:
        return 'man'
    return ''


def _species(core: str) -> str:
    low = core.lower()
    for species in sorted(SPECIES_TO_FAMILY, key=len, reverse=True):
        if re.search(r'\b' + re.escape(species) + r'\b', low):
            return species
    if re.search(r'\bmerman\b', low):
        return 'mermaid'
    if re.search(r'\bincubus\b', low):
        return 'succubus'
    return ''


class ACL4BuildMetadataJSON:
    CATEGORY = 'Anime Creature Lite v4'
    FUNCTION = 'build'
    RETURN_TYPES = ('STRING',)
    RETURN_NAMES = ('metadata_json',)

    @classmethod
    def INPUT_TYPES(cls):
        text = ('STRING', {'default': '', 'multiline': False})
        return {'required': {
            'resolved_prompt': ('STRING', {'default': '', 'multiline': True}),
            'character_core': text,
            'hair_style': text,
            'hair_accent': text,
            'eye_shape': text,
            'eye_accent': text,
            'outfit_woman': text,
            'outfit_man': text,
            'outfit_torso_woman': text,
            'outfit_torso_man': text,
            'trim': text,
            'accessory': text,
            'pose': text,
            'facing_direction': text,
            'scene_a': text,
            'scene_b': text,
            'lighting_tone': text,
            'secondary_lighting': text,
            'finish_style': text,
            'hair_color_primary': text,
            'hair_color_secondary': text,
            'eye_color_primary': text,
            'eye_color_secondary': text,
            'outfit_color': text,
            'trim_color': text,
            'accessory_color': text,
            'creature_color_primary': text,
            'creature_color_secondary': text,
        }}

    def build(self, **kwargs):
        cleaned = {k: _text(v) for k, v in kwargs.items()}
        core = cleaned.get('character_core', '')
        species = _species(core)
        metadata = {
            'schema': 'anime_creature_lite_v4/v1',
            'resolved_prompt': cleaned.get('resolved_prompt', ''),
            'character_core': core,
            'gender': _gender(core),
            'species': species,
            'creature_family': SPECIES_TO_FAMILY.get(species, ''),
            'global_selections': {k:v for k,v in cleaned.items() if k not in {'resolved_prompt','character_core'}},
        }
        return (json.dumps({'anime_creature_lite_v4': metadata}, ensure_ascii=False, indent=2),)


class ACL4SaveImageWithMetadata:
    CATEGORY = 'image'
    FUNCTION = 'save_images'
    OUTPUT_NODE = True
    RETURN_TYPES = ('IMAGE',)
    RETURN_NAMES = ('images',)

    def __init__(self):
        self.output_dir = folder_paths.get_output_directory() if folder_paths else os.getcwd()
        self.type = 'output'
        self.prefix_append = ''
        self.compress_level = 4

    @classmethod
    def INPUT_TYPES(cls):
        return {
            'required': {
                'images': ('IMAGE',),
                'metadata_json': ('STRING', {'default': '{}', 'multiline': True}),
                'filename_prefix': ('STRING', {'default': 'AnimeCreatureLiteV4'}),
                'write_sidecar_json': ('BOOLEAN', {'default': True}),
            },
            'hidden': {'prompt': 'PROMPT', 'extra_pnginfo': 'EXTRA_PNGINFO'},
        }

    def save_images(self, images, metadata_json, filename_prefix='AnimeCreatureLiteV4', write_sidecar_json=True, prompt=None, extra_pnginfo=None):
        filename_prefix = filename_prefix + self.prefix_append
        results = []
        for image in images:
            arr = 255.0 * image.cpu().numpy()
            img = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))
            if folder_paths:
                full_output_folder, filename, counter, subfolder, filename_prefix = folder_paths.get_save_image_path(filename_prefix, self.output_dir, img.width, img.height)
            else:
                full_output_folder, filename, counter, subfolder = self.output_dir, filename_prefix, 1, ''
            os.makedirs(full_output_folder, exist_ok=True)
            file = f'{filename}_{counter:05}_.png'
            out_path = os.path.join(full_output_folder, file)
            pnginfo = None
            if not getattr(args, 'disable_metadata', False):
                pnginfo = PngInfo()
                if prompt is not None:
                    pnginfo.add_text('prompt', json.dumps(prompt))
                if extra_pnginfo is not None:
                    for k, v in extra_pnginfo.items():
                        pnginfo.add_text(k, json.dumps(v))
                try:
                    parsed = json.loads(metadata_json)
                    pnginfo.add_text('anime_creature_lite_v4', json.dumps(parsed, ensure_ascii=False))
                except Exception:
                    pnginfo.add_text('anime_creature_lite_v4', metadata_json)
            img.save(out_path, pnginfo=pnginfo, compress_level=self.compress_level)
            if write_sidecar_json:
                sidecar = os.path.splitext(out_path)[0] + '.json'
                try:
                    parsed = json.loads(metadata_json)
                    with open(sidecar, 'w', encoding='utf-8') as f:
                        json.dump(parsed, f, ensure_ascii=False, indent=2)
                except Exception:
                    with open(sidecar, 'w', encoding='utf-8') as f:
                        f.write(metadata_json)
            results.append({'filename': file, 'subfolder': subfolder, 'type': self.type})
        return {'ui': {'images': results}, 'result': (images,)}


NODE_CLASS_MAPPINGS = {
    'ACL4_BuildMetadataJSON': ACL4BuildMetadataJSON,
    'ACL4_SaveImageWithMetadata': ACL4SaveImageWithMetadata,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    'ACL4_BuildMetadataJSON': 'Creature Lite v4 Build Metadata JSON',
    'ACL4_SaveImageWithMetadata': 'Creature Lite v4 Save Image With Metadata',
}
