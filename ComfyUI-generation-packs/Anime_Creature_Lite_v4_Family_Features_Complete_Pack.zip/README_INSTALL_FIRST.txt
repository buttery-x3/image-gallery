ANIME CREATURE LITE V4 — FAMILY FEATURES

WHAT THIS VERSION CHANGES
- Restores separate hair, eye, outfit, trim, accessory and creature colour variation.
- Keeps the simple Anime Waifu Lite scene and lighting system.
- Uses 1woman / 1man plus adult woman / adult man in every character core.
- Uses simple common words only: brown fur, blue scales, large ears, long tail, smooth skin.
- Creature features are matched through family-specific feature files.
- Each family has a mandatory feature bundle, an optional marking slot, and a 5% rare slot.

INSTALL
1. Extract the CONTENTS of this zip into your ComfyUI root folder.
2. Allow the custom_nodes and data folders to merge with existing folders.
3. Restart ComfyUI.
4. Import workflows/Anime_Creature_Lite_v4_Metadata_Workflow.json.
5. Change the model / CLIP / VAE loaders to your own files if needed.

EZ-AF NODE REQUIREMENT
The workflow expects ComfyUI-EZ-AF-Nodes to already be installed. This pack only adds data under that node's data/prompts and data/tags folders.

IMPORTANT
The workflow is intentionally large because each creature family has its own replacement slots. Only the slots named inside the selected character core appear in the final prompt; unrelated family replacements simply find nothing and do not alter the prompt.

The custom metadata saver stores the resolved prompt and the main global selections in PNG metadata and an optional sidecar JSON.
