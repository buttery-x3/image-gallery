ANIME WAIFU LITE COMPLETE PACK

Install:
1. Extract this zip into your ComfyUI root folder.
2. Restart ComfyUI.
3. Import workflows/Anime_Waifu_Lite_Metadata_Workflow.json

Contents:
- custom_nodes/ComfyUI-EZ-AF-Nodes/...
- custom_nodes/ComfyUI-AnimeWaifuMetadata/...
- workflows/Anime_Waifu_Lite_Metadata_Workflow.json

Notes:
- The workflow keeps your uploaded Anima base setup.
- The Save node writes searchable JSON metadata to the PNG and .json sidecars.
- If Anime_Waifu_Lite does not appear in EZ-AF dropdowns immediately, restart ComfyUI again.
