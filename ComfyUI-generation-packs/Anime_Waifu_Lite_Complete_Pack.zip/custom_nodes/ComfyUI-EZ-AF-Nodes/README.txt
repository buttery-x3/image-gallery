ANIME WAIFU LITE — EZ-AF PROMPT PACK

Designed for lighter anime checkpoints that respond better to concise prompts.

Prompt structure:
- fixed anime base and adult reinforcement;
- body type and breast type;
- independently coloured hair, eyes, outfit, trim, and jewellery;
- one outfit, one pose, one facing direction;
- one broad scene and one optional scene detail;
- one lighting tone and one optional secondary light;
- one short final rendering treatment.

There is no separate composition slot and no broad theme/motif paragraph.

FILES
Tag categories: 17
Physical selectable lines: 645
Visual colours: 72
Body types: 24
Outfits: 54
Poses: 45
Finish styles: 80
Scene locations: 48

The repeated [empty] lines in optional files are deliberate and must not be removed.
