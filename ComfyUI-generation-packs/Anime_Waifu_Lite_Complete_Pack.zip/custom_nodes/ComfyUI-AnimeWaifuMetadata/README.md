# ComfyUI-AnimeWaifuMetadata

Two lightweight CPU-safe helper nodes:

1. **AWL Build Metadata JSON**
2. **AWL Save Image With Metadata**

The saver embeds structured JSON into PNG metadata under the key `anime_waifu_lite`
and can also write a `.json` sidecar file next to each image.
