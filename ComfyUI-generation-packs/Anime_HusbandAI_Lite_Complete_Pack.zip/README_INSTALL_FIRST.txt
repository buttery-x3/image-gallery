ANIME HUSBANDAI LITE — COMPLETE PACK

This pack is a sibling to Anime Waifu Lite, tuned for adult anime men.
It includes:
- EZ-AF prompt template and tag files
- Negative prompt
- Placeholder map and installation guide
- Metadata sidecar / PNG custom node
- HusbandAI naming schema draft

INSTALL
1. Extract this archive into your ComfyUI folder.
2. Merge the included custom_nodes folders with your existing custom_nodes.
3. Restart ComfyUI.
4. Follow INSTALL_AND_NODE_WIRING_GUIDE.txt for wiring.

WORKFLOW
Import workflows/Anime_HusbandAI_Lite_Metadata_Workflow.json after installing the included prompt/tag files and metadata custom node.
The workflow uses the same AnimaYume / Qwen model-loader, sampler, and save structure as the supplied reference workflows.
