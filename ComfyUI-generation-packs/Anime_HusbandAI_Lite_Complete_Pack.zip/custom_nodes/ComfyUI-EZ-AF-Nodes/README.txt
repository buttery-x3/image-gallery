Anime HusbandAI Lite prompt pack for EZ-AF Nodes. Copy the files into ComfyUI-EZ-AF-Nodes and wire according to the guide.
