import json
import os
from typing import Any, List

import numpy as np
from PIL import Image
from PIL.PngImagePlugin import PngInfo

try:
    import folder_paths
except Exception:
    folder_paths = None

try:
    from comfy.cli_args import args
except Exception:
    class _Args:
        disable_metadata = False
    args = _Args()


def _text(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, str):
        return v.strip()
    return str(v).strip()


def _active(v: str) -> bool:
    return bool(_text(v))


def _split_color_tokens(v: str) -> List[str]:
    raw = _text(v)
    if not raw:
        return []
    s = raw.lower().replace(",", " ").replace("/", " ")
    s = s.replace("gradient", " gradient ")
    parts = []
    for p in s.split():
        if "-" in p:
            parts.extend([x for x in p.split("-") if x])
        else:
            parts.append(p)
    seen = set()
    out = []
    for t in [raw] + parts:
        t = t.strip()
        if t and t not in seen:
            out.append(t)
            seen.add(t)
    return out


def _resolve_placeholders(text: str, mapping: dict[str, str]) -> str:
    s = _text(text)
    if not s:
        return ""
    for k, v in mapping.items():
        s = s.replace(k, _text(v))
    return s.strip()


class AHLBuildMetadataJSON:
    CATEGORY = "Anime HusbandAI Lite"
    FUNCTION = "build"
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("metadata_json",)

    @classmethod
    def INPUT_TYPES(cls):
        text = ("STRING", {"default": "", "multiline": False})
        return {
            "required": {
                "resolved_prompt": ("STRING", {"default": "", "multiline": True}),
                "face_archetype": text,
                "body_build": text,
                "skin_tone": text,
                "hair_style": text,
                "hair_color_primary": text,
                "hair_color_secondary": text,
                "hair_accent": text,
                "eye_shape": text,
                "eye_color_primary": text,
                "eye_color_secondary": text,
                "eye_accent": text,
                "facial_hair": text,
                "face_detail": text,
                "outfit": text,
                "outfit_color": text,
                "trim": text,
                "trim_color": text,
                "accessory": text,
                "accessory_color": text,
                "expression": text,
                "pose": text,
                "facing_direction": text,
                "scene": text,
                "scene_detail": text,
                "lighting": text,
                "secondary_lighting": text,
                "finish_style": text,
            }
        }

    def build(self, **kwargs):
        cleaned = {k: _text(v) for k, v in kwargs.items()}

        cleaned["hair_accent"] = _resolve_placeholders(cleaned.get("hair_accent", ""), {"@@HAIRCOLOR2@@": cleaned.get("hair_color_secondary", "")})
        cleaned["eye_accent"] = _resolve_placeholders(cleaned.get("eye_accent", ""), {"@@EYECOLOR1@@": cleaned.get("eye_color_primary", ""), "@@EYECOLOR2@@": cleaned.get("eye_color_secondary", "")})
        cleaned["trim"] = _resolve_placeholders(cleaned.get("trim", ""), {"@@TRIMCOLOR@@": cleaned.get("trim_color", "")})
        cleaned["accessory"] = _resolve_placeholders(cleaned.get("accessory", ""), {"@@ACCESSORYCOLOR@@": cleaned.get("accessory_color", "")})

        metadata = {
            "schema": "anime_husbandai_lite/v1",
            "resolved_prompt": cleaned.pop("resolved_prompt", ""),
            **cleaned,
            "active_flags": {
                "skin_tone_active": _active(cleaned.get("skin_tone", "")),
                "hair_accent_active": _active(cleaned.get("hair_accent", "")),
                "eye_accent_active": _active(cleaned.get("eye_accent", "")),
                "facial_hair_active": _active(cleaned.get("facial_hair", "")),
                "face_detail_active": _active(cleaned.get("face_detail", "")),
                "trim_active": _active(cleaned.get("trim", "")),
                "accessory_active": _active(cleaned.get("accessory", "")),
                "scene_detail_active": _active(cleaned.get("scene_detail", "")),
                "secondary_lighting_active": _active(cleaned.get("secondary_lighting", "")),
            },
            "search_tokens": {
                "hair_color_primary": _split_color_tokens(cleaned.get("hair_color_primary", "")),
                "hair_color_secondary": _split_color_tokens(cleaned.get("hair_color_secondary", "")),
                "eye_color_primary": _split_color_tokens(cleaned.get("eye_color_primary", "")),
                "eye_color_secondary": _split_color_tokens(cleaned.get("eye_color_secondary", "")),
                "outfit_color": _split_color_tokens(cleaned.get("outfit_color", "")),
                "trim_color": _split_color_tokens(cleaned.get("trim_color", "")),
                "accessory_color": _split_color_tokens(cleaned.get("accessory_color", "")),
            }
        }
        return (json.dumps({"anime_husbandai_lite": metadata}, ensure_ascii=False, indent=2),)


class AHLSaveImageWithMetadata:
    CATEGORY = "image"
    FUNCTION = "save_images"
    OUTPUT_NODE = True
    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("images",)

    def __init__(self):
        self.output_dir = folder_paths.get_output_directory() if folder_paths else os.getcwd()
        self.type = "output"
        self.prefix_append = ""
        self.compress_level = 4

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "images": ("IMAGE",),
                "metadata_json": ("STRING", {"default": "{}", "multiline": True}),
                "filename_prefix": ("STRING", {"default": "AnimeHusbandAILite"}),
                "write_sidecar_json": ("BOOLEAN", {"default": True}),
            },
            "hidden": {
                "prompt": "PROMPT",
                "extra_pnginfo": "EXTRA_PNGINFO",
            },
        }

    def _get_path_parts(self, filename_prefix, width, height):
        if folder_paths:
            return folder_paths.get_save_image_path(filename_prefix, self.output_dir, width, height)
        os.makedirs(self.output_dir, exist_ok=True)
        return self.output_dir, filename_prefix, 1, "", filename_prefix

    def save_images(self, images, metadata_json, filename_prefix="AnimeHusbandAILite", write_sidecar_json=True, prompt=None, extra_pnginfo=None):
        filename_prefix = filename_prefix + self.prefix_append
        results = []
        for image in images:
            arr = 255.0 * image.cpu().numpy()
            img = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))
            full_output_folder, filename, counter, subfolder, filename_prefix = self._get_path_parts(filename_prefix, img.width, img.height)
            os.makedirs(full_output_folder, exist_ok=True)
            file = f"{filename}_{counter:05}_.png"
            out_path = os.path.join(full_output_folder, file)
            pnginfo = None
            if not getattr(args, "disable_metadata", False):
                pnginfo = PngInfo()
                if prompt is not None:
                    pnginfo.add_text("prompt", json.dumps(prompt))
                if extra_pnginfo is not None:
                    for k, v in extra_pnginfo.items():
                        pnginfo.add_text(k, json.dumps(v))
                try:
                    parsed = json.loads(metadata_json)
                    pnginfo.add_text("anime_husbandai_lite", json.dumps(parsed, ensure_ascii=False))
                except Exception:
                    pnginfo.add_text("anime_husbandai_lite", metadata_json)
            img.save(out_path, pnginfo=pnginfo, compress_level=self.compress_level)
            if write_sidecar_json:
                sidecar = os.path.splitext(out_path)[0] + ".json"
                try:
                    parsed = json.loads(metadata_json)
                    with open(sidecar, "w", encoding="utf-8") as f:
                        json.dump(parsed, f, ensure_ascii=False, indent=2)
                except Exception:
                    with open(sidecar, "w", encoding="utf-8") as f:
                        f.write(metadata_json)
            results.append({"filename": file, "subfolder": subfolder, "type": self.type})
        return {"ui": {"images": results}, "result": (images,)}


NODE_CLASS_MAPPINGS = {
    "AHL_BuildMetadataJSON": AHLBuildMetadataJSON,
    "AHL_SaveImageWithMetadata": AHLSaveImageWithMetadata,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "AHL_BuildMetadataJSON": "AHL Build Metadata JSON",
    "AHL_SaveImageWithMetadata": "AHL Save Image With Metadata",
}
