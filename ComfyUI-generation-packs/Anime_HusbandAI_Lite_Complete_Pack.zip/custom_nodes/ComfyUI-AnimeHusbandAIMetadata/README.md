Custom nodes to save Anime HusbandAI Lite metadata into PNG text chunks and JSON sidecars.
